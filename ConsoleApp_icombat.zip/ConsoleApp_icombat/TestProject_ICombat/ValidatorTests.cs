using ConsoleApp_ICombat.Classes;

namespace TestProject_ICombat
{
    [TestClass]
    public class ValidatorTests
    {
        Validator validator = new Validator();

        [TestMethod]
        public void Test_VariousInputs()
        {
            //Arrange
            string input = "";

            //Act
            var res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "adfasdf";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "I";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "r";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsTrue(res);
        }

        [TestMethod]
        public void Test_QueryDenomination_VariousInputs()
        {
            //Arrange
            string input = "I $30";

            //Act
            var res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "I $20 $50";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsTrue(res);

            //Arrange
            input = "I$20 $5$";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "I$20 $5-";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);
        }

        [TestMethod]
        public void Test_Withdraw_VariousInputs()
        {
            //Arrange
            string input = "w 30";

            //Act
            var res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "w$30";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "w $30";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsTrue(res);

            //Arrange
            input = "w $20 $5-";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsFalse(res);

            //Arrange
            input = "w $2000";

            //Act
            res = validator.ValidateInput(input);

            //Assert
            Assert.IsTrue(res);
        }
    }
}