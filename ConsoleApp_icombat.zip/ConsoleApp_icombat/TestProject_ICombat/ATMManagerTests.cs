using ConsoleApp_ICombat.Classes;

namespace TestProject_ICombat
{
    [TestClass]
    public class ATMManagerTests
    {
        ATMManager _atmManager = new ATMManager();

        //[TestMethod]
        //public void Test_VariousInputs()
        //{
        //    //Arrange
        //    string input = "";

        //    //Act
        //    var res = _atmManager.ValidateInput(input);

        //    //Assert
        //    Assert.IsFalse(res);

        //    //Arrange
        //    input = "adfasdf";

        //    //Act
        //    res = _atmManager.ValidateInput(input);

        //    //Assert
        //    Assert.IsFalse(res);

        //    //Arrange
        //    input = "I";

        //    //Act
        //    res = _atmManager.ValidateInput(input);

        //    //Assert
        //    Assert.IsFalse(res);

        //    //Arrange
        //    input = "r";

        //    //Act
        //    res = _atmManager.ValidateInput(input);

        //    //Assert
        //    Assert.IsTrue(res);
        //}

        [TestMethod]
        public void Test_QueryDenomination_VariousInputs()
        {
            //Arrange
            string input = "I $20";

            //Act
            var res = _atmManager.QueryDenominations(input);

            //Assert
            Assert.AreEqual(res[0], $"$20 - {_atmManager._twentyDollar.Quantity}");

            //Arrange
            input = "I $20 $50";

            //Act
            res = _atmManager.QueryDenominations(input);

            //Assert
            Assert.AreEqual(res[0], $"$20 - {_atmManager._twentyDollar.Quantity}");
            Assert.AreEqual(res[1], $"$50 - {_atmManager._fiftyDollar.Quantity}");
        }

        [TestMethod]
        public void Test_Withdraw_VariousInputs()
        {
            //Arrange
            string input = "w $30";

            //Act
            var res = _atmManager.Withdraw(input);

            //Assert
            Assert.IsTrue(res.IsSuccess);
            Assert.AreEqual(res.ResultDetail, "Dispensed $30");

            //Arrange
            input = "w $2000";

            //Act
            res = _atmManager.Withdraw(input);

            //Assert
            Assert.IsFalse(res.IsSuccess);
            Assert.AreEqual(res.ResultDetail, "Insufficient funds");
        }
    }
}