﻿public class OperationResult
{
    public bool IsSuccess { get; set; }
    public string? ResultDetail { get; set; }
}