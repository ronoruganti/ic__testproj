﻿using ConsoleApp_ICombat.Interfaces;
using ConsoleApp_ICombat.Models;

namespace ConsoleApp_ICombat.Classes
{
    /// <summary>
    /// Manages operation of the ATM app
    /// </summary>
    public class ATMManager : IATMManager
    {
        public ICurrencyBill _hundredDollar = new CurrencyBill(100);
        public ICurrencyBill _fiftyDollar = new CurrencyBill(50);
        public ICurrencyBill _twentyDollar = new CurrencyBill(20);
        public ICurrencyBill _tenDollar = new CurrencyBill(10);
        public ICurrencyBill _fiveDollar = new CurrencyBill(5);
        public ICurrencyBill _oneDollar = new CurrencyBill(1);

        /// <summary>
        /// ctor
        /// </summary>
        public ATMManager() { }

        /// <summary>
        /// Get total machine balance
        /// </summary>
        /// <returns></returns>
        private int GetMachineBalance()
        {
            return _hundredDollar.Amount +
                _fiftyDollar.Amount +
                _twentyDollar.Amount +
                _tenDollar.Amount +
                _fiveDollar.Amount +
                _oneDollar.Amount;
        }

        /// <summary>
        /// Withdraw on a bill by bill basis
        /// </summary>
        /// <param name="withdrawalAmount"></param>
        private void WithdrawByDenominations(int withdrawalAmount)
        {
            var amount = 0;
            if (withdrawalAmount >= 100)
            {
                amount = _hundredDollar.TakeBills(_hundredDollar.Quantity > withdrawalAmount / 100 ? withdrawalAmount / 100 : _hundredDollar.Quantity);
                withdrawalAmount = withdrawalAmount - amount;
            }
            if (withdrawalAmount >= 50)
            {
                amount = _fiftyDollar.TakeBills(_fiftyDollar.Quantity > withdrawalAmount / 50 ? withdrawalAmount / 50 : _fiftyDollar.Quantity);
                withdrawalAmount = withdrawalAmount - amount;
            }
            if (withdrawalAmount >= 20)
            {
                amount = _twentyDollar.TakeBills(_twentyDollar.Quantity > withdrawalAmount / 20 ? withdrawalAmount / 20 : _twentyDollar.Quantity);
                withdrawalAmount = withdrawalAmount - amount;
            }
            if (withdrawalAmount >= 10)
            {
                amount = _tenDollar.TakeBills(_tenDollar.Quantity > withdrawalAmount / 10 ? withdrawalAmount / 10 : _tenDollar.Quantity);
                withdrawalAmount = withdrawalAmount - amount;
            }
            if (withdrawalAmount >= 5)
            {
                amount = _fiveDollar.TakeBills(_fiveDollar.Quantity > withdrawalAmount / 5 ? withdrawalAmount / 5 : _fiveDollar.Quantity);
                withdrawalAmount = withdrawalAmount - amount;
            }
            if (withdrawalAmount >= 1)
            {
                amount = _oneDollar.TakeBills(_oneDollar.Quantity > withdrawalAmount / 1 ? withdrawalAmount / 1 : _oneDollar.Quantity);
                withdrawalAmount = withdrawalAmount - amount;
            }
        }

        /// <summary>
        /// Reset funds in the machine
        /// </summary>
        public OperationResult RestockMachine()
        {
            _hundredDollar.Quantity = 10;
            _fiftyDollar.Quantity = 10;
            _twentyDollar.Quantity = 10;
            _tenDollar.Quantity = 10;
            _fiveDollar.Quantity = 10;
            _oneDollar.Quantity = 10;

            return new OperationResult { IsSuccess = true };
        }

        /// <summary>
        /// Withdraw funds
        /// </summary>
        /// <param name="payLoad"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public OperationResult Withdraw(string inputUpper)
        {
            var payLoad = inputUpper.Split(" ")[1].ToString();

            int.TryParse(payLoad.Split("$")[1], out int withdrawalAmount);

            if (GetMachineBalance() < withdrawalAmount)
                return new OperationResult { IsSuccess = false, ResultDetail = "Insufficient funds" };
            
            WithdrawByDenominations(withdrawalAmount);
            
            return new OperationResult { IsSuccess = true, ResultDetail = $"Dispensed {payLoad}" };
        }

        /// <summary>
        /// Show available balance on a denom basis
        /// </summary>
        public List<string> CompileBalance()
        {
            List<string> res = new List<string>();

            res.Add("Machine Balance:");
            res.Add($"$100 - {_hundredDollar.Quantity}");
            res.Add($"$50 - {_fiftyDollar.Quantity}");
            res.Add($"$20 - {_twentyDollar.Quantity}");
            res.Add($"$10 - {_tenDollar.Quantity}");
            res.Add($"$5 - {_fiveDollar.Quantity}");
            res.Add($"$1 - {_oneDollar.Quantity}");

            return res;
        }

        /// <summary>
        /// Query quantity by bill denomination
        /// </summary>
        /// <param name="denom"></param>
        /// <returns></returns>
        public List<string> QueryDenominations(string inputUpper)
        {
            var denom = inputUpper.Split(" ").Skip(1).Take(inputUpper.Length - 1).ToList();

            List<string> res = new List<string>();
            foreach (var str in denom)
            {
                var qty = string.Empty;

                switch (str)
                {
                    case "$100":
                        qty = str + " - " + _hundredDollar.Quantity.ToString();
                        break;
                    case "$50":
                        qty = str + " - " + _fiftyDollar.Quantity.ToString();
                        break;
                    case "$20":
                        qty = str + " - " + _twentyDollar.Quantity.ToString();
                        break;
                    case "$10":
                        qty = str + " - " + _tenDollar.Quantity.ToString();
                        break;
                    case "$5":
                        qty = str + " - " + _fiveDollar.Quantity.ToString();
                        break;
                    case "$1":
                        qty = str + " - " + _oneDollar.Quantity.ToString();
                        break;
                    default:
                        throw new InvalidDataException();
                }

                res.Add(qty);
            }

            return res;
        }
    }
}
