﻿using ConsoleApp_ICombat.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ICombat.Classes
{
    public class Validator : IValidator
    {
        /// <summary>
        /// Validate input
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public bool ValidateInput(string input)
        {
            if (input == null || input == string.Empty)
                return false;

            if (input.Length > 1)                
            {
                if (input.Split(" ")[0].Length > 1)
                    return false;
            }

            var firstChar = input.Substring(0, 1).ToUpper();

            if (!(firstChar != "R" || firstChar != "W" || firstChar != "I" || firstChar != "Q"))
                return false;

            if ((firstChar == "R" || firstChar == "Q") && input.Length == 1)
                return true;
            else
            {
                var inputArr = input.Split(" ");
                if (inputArr.Length < 2)
                    return false;

                switch (firstChar)
                {
                    case "W":
                        {
                            if (inputArr.Length > 2)
                                return false;

                            if (inputArr[1].Substring(0, 1) != "$")
                                return false;

                            if (!(int.TryParse(inputArr[1].Split("$")[1], out int outAmt)))
                                return false;

                            if (outAmt <= 0)
                                return false;
                        }
                        break;
                    case "I":
                        {
                            List<string> denomArr = new List<string>();
                            if (inputArr.Length == 2)
                                denomArr.Add(inputArr[1]);
                            else
                                denomArr = inputArr[1].Split(" ").ToList();

                            if (denomArr.Any(x => x.Substring(0, 1) != "$"))
                                return false;

                            foreach (var denom in denomArr)
                            {
                                if (!(int.TryParse(denom.Split("$")[1], out int outAmt)))
                                    return false;

                                if (outAmt != 100 && outAmt != 50 && outAmt != 20 && outAmt != 10 && outAmt != 5 && outAmt != 1)
                                    return false;
                            }
                        }
                        break;
                    default:
                        return false;
                }
            }
            return true;
        }
    }
}
