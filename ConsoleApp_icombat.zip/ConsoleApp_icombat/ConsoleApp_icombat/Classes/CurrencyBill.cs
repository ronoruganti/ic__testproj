﻿using ConsoleApp_ICombat.Interfaces;

namespace ConsoleApp_ICombat.Models
{
    /// <summary>
    /// Class representing currency bill of various deniominations
    /// </summary>
    public class CurrencyBill : ICurrencyBill
    {
        private int _quantity = 10;

        public int Quantity { get => _quantity; set => _quantity = value; }

        public int Amount => Value * Quantity;

        public int Value { get; }

        public CurrencyBill(int value)
        {
            Value = value;
        }

        /// <summary>
        /// Disburses money on a bill by bill basis
        /// </summary>
        /// <param name="number"></param>
        /// <returns>amount disbursed</returns>
        public int TakeBills(int number)
        {
            Quantity = Quantity - number;
            var disbursedAmount = number * Value;
            return disbursedAmount;
        }
    }
}
