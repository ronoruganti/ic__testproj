﻿namespace ConsoleApp_ICombat.Interfaces
{
    /// <summary>
    /// Interface for currency bill representing various denominations
    /// </summary>
    public interface ICurrencyBill
    {
        public int Quantity { get; set; }
        public int Amount { get; }
        public int Value { get; }

        public int TakeBills(int number);
    }
}
