﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_ICombat.Interfaces
{
    public interface IATMManager
    {
        OperationResult RestockMachine();
        OperationResult Withdraw(string payLoad);
        List<string> CompileBalance();
        List<string> QueryDenominations(string inputUpper);
    }
}
