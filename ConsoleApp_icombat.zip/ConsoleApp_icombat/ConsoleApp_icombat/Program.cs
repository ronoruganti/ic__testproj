﻿using ConsoleApp_ICombat.Classes;
using ConsoleApp_ICombat.Interfaces;

class Program
{
    static IATMManager _aTMManager = new ATMManager();
    static IValidator _validator = new Validator();

    static void Main()
    {
        bool _quit = false;

        while (!_quit)
        {
            ShowMainMenuPrompts();

            var input = Console.ReadLine();

            //Just a safeguard
            if (input == null)
                return;

            if (input.ToUpper() == "Q")
                _quit = true;

            if (!_validator.ValidateInput(input.ToString().Trim().ToUpper()))
            {
                ShowInvalidCommandMessage();
                continue;
            }

            ProcessCommand(input.ToString().Trim().ToUpper());
        }
        return;
    }

    /// <summary>
    /// Process command 
    /// </summary>
    /// <param name="input"></param>
    private static void ProcessCommand(string inputUpper)
    {
        var _success = new OperationResult();

        var command = inputUpper.Split(" ")[0].ToString();

        try
        {
            switch (command)
            {
                case "R":
                    _success = _aTMManager.RestockMachine();
                    if (_success.IsSuccess)
                        ShowResult(_aTMManager.CompileBalance());
                    break;
                case "I":
                    ShowResult(_aTMManager.QueryDenominations(inputUpper));
                    break;
                case "W":
                    _success = _aTMManager.Withdraw(inputUpper);
                    if (_success.IsSuccess)
                    {
                        Console.WriteLine($"Success: {_success.ResultDetail}");
                        ShowResult(_aTMManager.CompileBalance());
                    }
                    else
                    {
                        Console.WriteLine($"Failure: {_success.ResultDetail}");
                        ResetMenu();
                    }
                    break;
                default:
                    break;
            }
        }
        catch (Exception)
        {
            Console.WriteLine($"\nFailure: Invalid Command");
            ResetMenu();
        }
    }

    /// <summary>
    /// Display result to user
    /// </summary>
    /// <param name="resultToDisplay"></param>
    private static void ShowResult(List<string> resultToDisplay)
    {
        foreach (var str in resultToDisplay)
        {
            Console.WriteLine(str);
        }

        ResetMenu();
    }

    /// <summary>
    /// Show 'Invalid Command' message
    /// </summary>
    private static void ShowInvalidCommandMessage()
    {
        Console.WriteLine("\nFailure: Invalid Command");
        ResetMenu();
    }

    /// <summary>
    /// Reset the menu
    /// </summary>
    private static void ResetMenu()
    {
        Console.WriteLine("\nPress any key to continue..");
        Console.ReadLine();
        Console.Clear();
    }

    /// <summary>
    /// Show input menu
    /// </summary>
    private static void ShowMainMenuPrompts()
    {
        Console.WriteLine("ATM App - Menu\r");
        Console.WriteLine("Written By Tanuj\r");
        Console.WriteLine("------------------------\n");

        Console.WriteLine("Press 'R' to Restock the machine\n");
        Console.WriteLine("Enter 'W $DollarAmount' to Withdraw e.g. W $208\n");
        Console.WriteLine("Enter 'I $Denominations' to Query. Enter I $Denomination $Denomination... to query multiple e.g. I $100 $50\n");
        Console.WriteLine("Enter 'Q' to Quit\n");
    }
}